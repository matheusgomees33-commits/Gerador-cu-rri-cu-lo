// ================================================
//   PROCESSO SELETIVO COM GEMINI GEMS — TECH-ZL · ADS 2026
//   empresa.js — Lógica completa da página Para Empresas
//   Integração: Gemini Gems (gratuito, sem API key)
// ================================================

// ---- ESTADO ----
let vagas        = [];
let contVaga     = 0;
let vagaReqTexto = {}; // guarda o texto de requisitos por vaga.id

// ---- PROMPT DO AGENTE GEMS ----
const GEMS_AGENT_PROMPT = `Você é um Agente Especialista em Recrutamento e Seleção de Talentos.

Sua missão é analisar currículos de candidatos com base nos requisitos técnicos de vagas fornecidos, de forma objetiva, profissional e 100% imparcial.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
FLUXO DE TRABALHO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ETAPA 1 — AO RECEBER OS REQUISITOS DA VAGA:
Quando receber os requisitos técnicos de uma vaga, confirme que os leu e SOLICITE ao recrutador que cole os currículos dos candidatos para análise. Aguarde o envio antes de prosseguir.

Modelo de resposta ao receber os requisitos:
"✅ Requisitos da vaga [TÍTULO DA VAGA] recebidos e registrados!
Agora cole os currículos dos candidatos para que eu inicie a triagem.
Para múltiplos candidatos, separe cada currículo com uma linha '---'."

ETAPA 2 — AO RECEBER OS CURRÍCULOS:
Após receber os currículos, analise cada candidato individualmente e de forma justa.
Para cada candidato, gere obrigatoriamente a análise no formato abaixo:

━━━ ANÁLISE DO CANDIDATO ━━━
Nome do Candidato: [nome completo ou "Candidato X" se não identificado]
Pontuação: [número de 0 a 10] / 10
Compatibilidade: [porcentagem estimada de requisitos atendidos]
Status: [APROVADO ✅ | EM ANÁLISE ⚠️ | NÃO RECOMENDADO ❌]
Pontos fortes: [lista dos principais pontos positivos em relação à vaga]
Pontos de atenção: [lacunas, requisitos não atendidos ou pontos negativos]
Recomendação: [texto objetivo com sua recomendação final]
━━━━━━━━━━━━━━━━━━━━━━━━━━━

Ao finalizar todos os candidatos, apresente um RANKING FINAL do mais ao menos recomendado para a vaga.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CRITÉRIOS DE CLASSIFICAÇÃO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ APROVADO (Pontuação ≥ 7/10)
   Candidato atende aos requisitos principais e é recomendado para entrevista.

⚠️ EM ANÁLISE (Pontuação entre 4 e 6/10)
   Candidato tem potencial, mas apresenta lacunas relevantes. Considerar entrevista.

❌ NÃO RECOMENDADO (Pontuação ≤ 3/10)
   Candidato não atende aos requisitos mínimos da vaga no momento.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
REGRAS OBRIGATÓRIAS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

• SEMPRE solicite os currículos se ainda não foram fornecidos — não inicie análise sem eles
• Analise APENAS com base nas informações fornecidas nos currículos
• Não faça suposições ou inferências sem embasamento nos dados
• Seja objetivo, profissional e use linguagem clara
• Mantenha postura ética, justa e sem viés de nenhum tipo
• Sempre responda em português do Brasil
• Separe a análise de cada candidato com uma linha de "---"
• Nunca invente informações que não estejam no currículo

Você está pronto para receber os requisitos da vaga.`;

// ---- BOOT ----
document.addEventListener('DOMContentLoaded', () => {
  initNavbar();
  adicionarVaga(); // já inicia com 1 vaga em branco
  preencherGemsPrompt();
});

// ================================================
//   PREENCHER PROMPT DO AGENTE GEMS NA TEXTAREA
// ================================================
function preencherGemsPrompt() {
  const ta = document.getElementById('gems-agent-prompt');
  if (ta) ta.value = GEMS_AGENT_PROMPT;
}

// ================================================
//   NAVBAR HAMBURGER
// ================================================
function initNavbar() {
  const hb   = document.getElementById('hamburger');
  const menu = document.getElementById('mobile-menu');
  if (hb && menu) {
    hb.addEventListener('click', () => menu.classList.toggle('aberto'));
  }
}

function fecharMenu() {
  document.getElementById('mobile-menu')?.classList.remove('aberto');
}

// ================================================
//   TOGGLE: EXIBIR/OCULTAR PROMPT GEMS
// ================================================
function toggleGemsPrompt() {
  const corpo  = document.getElementById('gems-prompt-corpo');
  const label  = document.getElementById('gems-toggle-label');
  if (!corpo) return;
  const aberto = corpo.style.display !== 'none';
  corpo.style.display = aberto ? 'none' : 'block';
  if (label) label.textContent = aberto ? '▼ Expandir' : '▲ Recolher';
}

// ================================================
//   VAGAS — CRUD
// ================================================
function adicionarVaga(titulo = '', area = '', requisitos = '', descricao = '', nivel = '') {
  contVaga++;
  vagas.push({
    id: 'vaga-' + contVaga,
    titulo,
    area,
    requisitos,
    descricao,
    nivel
  });
  renderizarVagas();
}

function removerVaga(id) {
  if (vagas.length <= 1) {
    mostrarToast('Mantenha pelo menos uma vaga cadastrada.', 'erro');
    return;
  }
  vagas = vagas.filter(v => v.id !== id);
  renderizarVagas();
}

function atualizarVaga(id, campo, valor) {
  const item = vagas.find(v => v.id === id);
  if (item) item[campo] = valor;
}

function renderizarVagas() {
  const container = document.getElementById('lista-vagas');
  if (!container) return;
  container.innerHTML = '';

  vagas.forEach((vaga, i) => {
    const card = document.createElement('div');
    card.className = 'vaga-card';
    card.innerHTML = `
      <div class="vaga-card__topo">
        <span class="vaga-card__num">Vaga ${i + 1}</span>
        <button class="vaga-card__rem" onclick="removerVaga('${vaga.id}')">Remover</button>
      </div>
      <div class="campo-linha">
        <div class="campo">
          <label>Título da vaga <span class="obrig">*</span></label>
          <input type="text" value="${esc(vaga.titulo)}"
            oninput="atualizarVaga('${vaga.id}', 'titulo', this.value)"
            placeholder="Ex: Desenvolvedor Front-End" />
        </div>
        <div class="campo">
          <label>Área / Departamento</label>
          <input type="text" value="${esc(vaga.area)}"
            oninput="atualizarVaga('${vaga.id}', 'area', this.value)"
            placeholder="Ex: Tecnologia, RH, Financeiro" />
        </div>
      </div>
      <div class="campo-linha">
        <div class="campo">
          <label>Nível de experiência</label>
          <select onchange="atualizarVaga('${vaga.id}', 'nivel', this.value)">
            <option value="" ${!vaga.nivel ? 'selected' : ''}>Selecione...</option>
            <option value="Estágio"       ${vaga.nivel === 'Estágio'       ? 'selected' : ''}>Estágio</option>
            <option value="Júnior"        ${vaga.nivel === 'Júnior'        ? 'selected' : ''}>Júnior</option>
            <option value="Pleno"         ${vaga.nivel === 'Pleno'         ? 'selected' : ''}>Pleno</option>
            <option value="Sênior"        ${vaga.nivel === 'Sênior'        ? 'selected' : ''}>Sênior</option>
            <option value="Especialista"  ${vaga.nivel === 'Especialista'  ? 'selected' : ''}>Especialista</option>
            <option value="Gerencial"     ${vaga.nivel === 'Gerencial'     ? 'selected' : ''}>Gerencial</option>
          </select>
        </div>
        <div class="campo">
          <label>Requisitos técnicos <small>(separados por vírgula)</small></label>
          <input type="text" value="${esc(vaga.requisitos)}"
            oninput="atualizarVaga('${vaga.id}', 'requisitos', this.value)"
            placeholder="JavaScript, React, Git, inglês intermediário" />
        </div>
      </div>
      <div class="campo">
        <label>Descrição da vaga / Responsabilidades</label>
        <textarea rows="3"
          oninput="atualizarVaga('${vaga.id}', 'descricao', this.value)"
          placeholder="Descreva as principais atividades, responsabilidades e benefícios da vaga...">${esc(vaga.descricao)}</textarea>
      </div>
    `;
    container.appendChild(card);
  });
}

// ================================================
//   PASSO 1 → 2: GERAR REQUISITOS TÉCNICOS
// ================================================
function gerarRequisitos() {
  const nomeEmpresa  = document.getElementById('nome-empresa')?.value.trim() || 'a empresa';
  const setorEmpresa = document.getElementById('setor-empresa')?.value.trim() || '';

  const vagasValidas = vagas.filter(v => v.titulo.trim());
  if (vagasValidas.length === 0) {
    mostrarToast('Preencha o título de pelo menos uma vaga antes de continuar.', 'erro');
    return;
  }

  const container = document.getElementById('lista-prompts');
  if (!container) return;
  container.innerHTML = '';

  // Limpa requisitos anteriores
  vagaReqTexto = {};

  vagasValidas.forEach((vaga, i) => {
    const textoReq = gerarTextoRequisitos(vaga, nomeEmpresa, setorEmpresa);
    // Guarda para uso no passo 3
    vagaReqTexto[vaga.id] = textoReq;

    const card = document.createElement('div');
    card.className = 'prompt-card';
    card.innerHTML = `
      <div class="prompt-card__topo">
        <span class="prompt-card__titulo">📄 Vaga ${i + 1}: ${esc(vaga.titulo)}${vaga.nivel ? ' — ' + esc(vaga.nivel) : ''}</span>
        <div class="prompt-card__acoes">
          <button class="btn-copiar" onclick="copiarPrompt(this, 'req-txt-${vaga.id}')">📋 Copiar</button>
        </div>
      </div>
      <textarea
        id="req-txt-${vaga.id}"
        class="prompt-card__textarea"
        rows="10"
        spellcheck="false"
        readonly
      >${esc(textoReq)}</textarea>
    `;
    container.appendChild(card);
  });

  // Popular select da triagem (passo 3)
  const select = document.getElementById('select-vaga-analise');
  if (select) {
    select.innerHTML = '<option value="">Selecione uma vaga...</option>';
    vagasValidas.forEach((vaga, i) => {
      const opt = document.createElement('option');
      opt.value = vaga.id;
      opt.textContent = `Vaga ${i + 1}: ${vaga.titulo}${vaga.nivel ? ' — ' + vaga.nivel : ''}`;
      select.appendChild(opt);
    });
  }

  // Mostrar passo 2
  document.getElementById('passo-1').style.display = 'none';
  const p2 = document.getElementById('passo-2');
  p2.style.display = 'block';
  setTimeout(() => p2.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80);
}

// ================================================
//   GERAR TEXTO DE REQUISITOS TÉCNICOS
// ================================================
function gerarTextoRequisitos(vaga, empresa, setor) {
  const setorTexto = setor ? ` | Setor: ${setor}` : '';
  const nivel      = vaga.nivel     ? vaga.nivel     : 'Não especificado';
  const area       = vaga.area      ? vaga.area      : 'Não especificada';
  const data       = new Date().toLocaleDateString('pt-BR');

  // Requisitos como lista com bullet
  const reqLista = vaga.requisitos
    ? vaga.requisitos
        .split(',')
        .map(r => r.trim())
        .filter(Boolean)
        .map(r => `  • ${r}`)
        .join('\n')
    : '  • (Não informado)';

  const descricao = vaga.descricao
    ? vaga.descricao.trim()
    : '(Não informada)';

  return `╔══════════════════════════════════════════════════════╗
  REQUISITOS TÉCNICOS DA VAGA
  ${empresa}${setorTexto}
  Gerado em: ${data} | Tech-ZL · ADS 2026
╚══════════════════════════════════════════════════════╝

▶ CARGO          : ${vaga.titulo}
▶ NÍVEL          : ${nivel}
▶ ÁREA           : ${area}

━━━ REQUISITOS TÉCNICOS OBRIGATÓRIOS ━━━
${reqLista}

━━━ RESPONSABILIDADES E ATIVIDADES ━━━
${descricao}

━━━ CRITÉRIOS DE AVALIAÇÃO ━━━
  ✅ APROVADO       — Atende ≥ 70% dos requisitos acima
  ⚠️ EM ANÁLISE     — Atende entre 40% e 69% dos requisitos
  ❌ NÃO RECOMENDADO — Atende menos de 40% dos requisitos

━━━ INSTRUÇÕES PARA O AGENTE GEMS ━━━
Para cada candidato analisado, forneça:
  1. Nome do candidato
  2. Pontuação de 0 a 10
  3. Status: APROVADO | EM ANÁLISE | NÃO RECOMENDADO
  4. Pontos fortes em relação a esta vaga
  5. Pontos de atenção / lacunas
  6. Recomendação final objetiva`;
}

// ================================================
//   NAVEGAÇÃO ENTRE PASSOS
// ================================================
function voltarPasso1() {
  document.getElementById('passo-2').style.display = 'none';
  const p1 = document.getElementById('passo-1');
  p1.style.display = 'block';
  setTimeout(() => p1.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80);
}

function irParaPasso3() {
  document.getElementById('passo-2').style.display = 'none';
  const p3 = document.getElementById('passo-3');
  p3.style.display = 'block';
  // Limpar resultado anterior
  const resultado = document.getElementById('resultado-analise');
  if (resultado) resultado.innerHTML = '';
  setTimeout(() => p3.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80);
}

function voltarPasso2() {
  document.getElementById('passo-3').style.display = 'none';
  const p2 = document.getElementById('passo-2');
  p2.style.display = 'block';
  setTimeout(() => p2.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80);
}

// ================================================
//   MOSTRAR REQUISITOS DA VAGA SELECIONADA
// ================================================
function mostrarRequisitosSelecionados() {
  const vagaId  = document.getElementById('select-vaga-analise')?.value;
  const bloco   = document.getElementById('bloco-requisitos-preview');
  const preview = document.getElementById('requisitos-preview');

  if (!vagaId || !bloco || !preview) {
    if (bloco) bloco.style.display = 'none';
    return;
  }

  const texto = vagaReqTexto[vagaId];
  if (texto) {
    preview.value      = texto;
    bloco.style.display = 'block';
  } else {
    bloco.style.display = 'none';
  }

  // Limpar resultado anterior ao trocar de vaga
  const resultado = document.getElementById('resultado-analise');
  if (resultado) resultado.innerHTML = '';
}

// ================================================
//   PASSO 3: PREPARAR MENSAGEM PARA O GEMS
//   — O site envia apenas os requisitos.
//   — O agente Gems solicitará os currículos no chat.
// ================================================
function prepararParaGemini() {
  const vagaId = document.getElementById('select-vaga-analise')?.value;

  if (!vagaId) {
    mostrarToast('Selecione uma vaga para o processo seletivo.', 'erro');
    return;
  }

  const vaga = vagas.find(v => v.id === vagaId);
  if (!vaga) {
    mostrarToast('Vaga não encontrada. Volte ao Passo 1.', 'erro');
    return;
  }

  const nomeEmpresa  = document.getElementById('nome-empresa')?.value.trim() || 'a empresa';
  const setorEmpresa = document.getElementById('setor-empresa')?.value.trim() || '';
  const requisitos   = vagaReqTexto[vagaId] || gerarTextoRequisitos(vaga, nomeEmpresa, setorEmpresa);

  const mensagem = gerarMensagemGemini(vaga, nomeEmpresa, setorEmpresa, requisitos);
  renderizarMensagemGemini(mensagem, vaga);
}

// ================================================
//   GERAR MENSAGEM DE REQUISITOS PARA O GEMS
//   — Apenas os requisitos técnicos da vaga.
//   — O agente pedirá os currículos no chat.
// ================================================
function gerarMensagemGemini(vaga, empresa, setor, requisitos) {
  const setorTexto = setor ? ` (${setor})` : '';
  return `[INÍCIO DO PROCESSO SELETIVO — ${vaga.titulo.toUpperCase()} | ${empresa}${setorTexto}]

${requisitos}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Esses são os requisitos técnicos da vaga acima.
Por favor, confirme o recebimento e solicite os currículos dos candidatos para iniciar a triagem.`;
}

// ================================================
//   RENDERIZAR MENSAGEM PARA O GEMS
// ================================================
function renderizarMensagemGemini(mensagem, vaga) {
  const resultadoDiv = document.getElementById('resultado-analise');
  if (!resultadoDiv) return;

  const msgId = 'msg-gems-' + vaga.id;

  resultadoDiv.innerHTML = `
    <div class="resultado-header">
      <h3>Mensagem pronta para o Agente Gems</h3>
      <span class="badge-ia">💎 Gems</span>
    </div>

    <div class="gems-resultado-instrucoes">
      <div class="gems-passo-instrucao">
        <span class="gems-passo-num">1</span>
        <span>Copie os requisitos abaixo</span>
      </div>
      <div class="gems-passo-instrucao">
        <span class="gems-passo-num">2</span>
        <span>Abra seu Agente Gems no Gemini e cole no chat</span>
      </div>
      <div class="gems-passo-instrucao">
        <span class="gems-passo-num">3</span>
        <span>O Gems confirmará os requisitos e pedirá os currículos — cole-os diretamente no chat do agente</span>
      </div>
    </div>

    <div class="prompt-card">
      <div class="prompt-card__topo">
        <span class="prompt-card__titulo">📋 Requisitos para o Gems — ${esc(vaga.titulo)}</span>
        <div class="prompt-card__acoes">
          <button class="btn-copiar" onclick="copiarPrompt(this, '${msgId}')">📋 Copiar mensagem</button>
        </div>
      </div>
      <textarea
        id="${msgId}"
        class="prompt-card__textarea"
        rows="16"
        spellcheck="false"
        readonly
      >${esc(mensagem)}</textarea>
    </div>

    <div class="gems-acoes-finais">
      <a
        href="https://gemini.google.com/app"
        target="_blank"
        class="btn btn--primary btn--lg gems-btn-abrir"
      >
        💎 Abrir Gemini Gems →
      </a>
      <a
        href="https://gemini.google.com/gems/create"
        target="_blank"
        class="btn btn--outline"
      >
        + Criar novo Agente Gems
      </a>
    </div>
  `;

  setTimeout(() => resultadoDiv.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100);
}

// ================================================
//   COPIAR PROMPT
// ================================================
function copiarPrompt(btn, textareaId) {
  const ta = document.getElementById(textareaId);
  if (!ta) return;

  navigator.clipboard.writeText(ta.value).then(() => {
    btn.textContent = '✅ Copiado!';
    btn.classList.add('copiado');
    setTimeout(() => {
      btn.textContent = '📋 Copiar';
      btn.classList.remove('copiado');
    }, 2000);
  }).catch(() => {
    // Fallback para browsers antigos
    ta.select();
    document.execCommand('copy');
    btn.textContent = '✅ Copiado!';
    setTimeout(() => { btn.textContent = '📋 Copiar'; }, 2000);
  });
}

// ================================================
//   LIMPAR TUDO
// ================================================
function limparTudo() {
  if (!confirm('Tem certeza que deseja limpar todos os dados?')) return;

  vagas        = [];
  contVaga     = 0;
  vagaReqTexto = {};

  const nomeEmp  = document.getElementById('nome-empresa');
  const setorEmp = document.getElementById('setor-empresa');
  if (nomeEmp)  nomeEmp.value  = '';
  if (setorEmp) setorEmp.value = '';

  const resultadoDiv = document.getElementById('resultado-analise');
  if (resultadoDiv) resultadoDiv.innerHTML = '';

  // Voltar ao passo 1
  document.getElementById('passo-2').style.display = 'none';
  document.getElementById('passo-3').style.display = 'none';
  document.getElementById('passo-1').style.display = 'block';

  adicionarVaga();
  mostrarToast('Dados limpos com sucesso.', 'ok');
}

// ================================================
//   TOAST NOTIFICATIONS
// ================================================
function mostrarToast(msg, tipo = 'ok') {
  document.querySelector('.toast-notif')?.remove();

  const toast = document.createElement('div');
  toast.className = 'toast-notif';
  toast.textContent = msg;

  Object.assign(toast.style, {
    position:     'fixed',
    bottom:       '28px',
    right:        '24px',
    zIndex:       '9999',
    background:   tipo === 'ok' ? '#1B3A6B' : '#DC2626',
    color:        '#fff',
    padding:      '12px 20px',
    borderRadius: '8px',
    fontSize:     '13.5px',
    fontWeight:   '600',
    boxShadow:    '0 4px 20px rgba(0,0,0,.2)',
    transition:   'opacity .3s',
    fontFamily:   "'Inter', sans-serif",
    maxWidth:     '320px'
  });

  document.body.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 350);
  }, 3000);
}

// ================================================
//   UTILITÁRIOS
// ================================================
function esc(str) {
  return (str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
